module.exports = {
  category: "giveaways",
  label: "Host a giveaway",
  emoji: "🎉",
};
