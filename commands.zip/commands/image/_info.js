module.exports = {
  category: "image",
  label: "Manipulate avatars and other images!",
  emoji: "🖼️",
};
