module.exports = {
  category: "emote",
  label: "Emote to your friends in style!",
  emoji: "🥳",
};
