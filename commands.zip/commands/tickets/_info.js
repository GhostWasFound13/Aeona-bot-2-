module.exports = {
  category: "tickets",
  label: "Let's configure your ticket system!",
  emoji: "🎫",
};
