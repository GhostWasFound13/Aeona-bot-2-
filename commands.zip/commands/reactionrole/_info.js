module.exports = {
  category: "reactionrole",
  label: "Let's Setup Some Reaction Roles!",
  emoji: "👍",
};
