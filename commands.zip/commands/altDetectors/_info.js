module.exports = {
  category: "altDetectors",
  label: "Find and remove alternate accounts",
  emoji: "📡",
};
