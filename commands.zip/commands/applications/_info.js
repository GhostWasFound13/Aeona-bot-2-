module.exports = {
  category: "Applications",
  label: "See and manage applications",
  emoji: "📝",
};
