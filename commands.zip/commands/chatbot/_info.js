module.exports = {
  category: "ChatBot",
  label: "Configure the chatbot",
  emoji: "💬",
};
