module.exports = {
  category: "info",
  label: "View Aeona's information commands",
  emoji: "‼️",
};
