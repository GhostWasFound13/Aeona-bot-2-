module.exports = {
  category: "music",
  label: "Let's enjoy some music together!",
  emoji: "🎶",
};
