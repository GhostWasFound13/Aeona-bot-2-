module.exports = {
  category: "fun",
  label: "Some fun commands",
  emoji: "👻",
};
