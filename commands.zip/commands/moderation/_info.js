module.exports = {
  category: "moderation",
  label: "Moderate your server with the wisdom of the gods",
  emoji: "🛠️",
};
