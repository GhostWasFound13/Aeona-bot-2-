module.exports = {
    category: "premium",
    label: "See Aeona's Premium Features",
    emoji: "💎",
  };
  