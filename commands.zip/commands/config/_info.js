module.exports = {
  category: "config",
  label: "Configure the bot to your liking",
  emoji: "🔧",
};
