module.exports = {
    category: "levels",
    label: "Setup Aeona Levels",
    emoji: "⚡",
  };
  