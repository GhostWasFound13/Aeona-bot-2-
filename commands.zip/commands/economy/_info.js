module.exports = {
  category: "economy",
  label: "The vast yet enticing econ. system",
  emoji: "💵",
};
