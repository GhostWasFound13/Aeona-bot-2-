module.exports = {
  category: "utility",
  label: "View Aeona's utility commands",
  emoji: "🔧",
};
