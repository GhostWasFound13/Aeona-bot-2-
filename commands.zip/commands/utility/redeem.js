const Guild = require("../../database/schemas/Guild");
const Premium = require("../../database/schemas/GuildPremium");
const moment = require("moment");
const Discord = require("discord.js");
const webhookClient = new Discord.WebhookClient({
  url: process.env.WEBHOOK_URL,
});
let uniqid = require("uniqid");

module.exports = {
  name: "redeem",
  description: "Redeem a premium code",
  usage: "+redeem <code>",
  category: "utility",
  requiredArgs: 1,
  execute: async (message, args, bot, prefix) => {
    let code = args[0];
    const guildDB = await Guild.findOne({
      guildId: message.guild.id,
    });

    if (guildDB.isPremium === "true")
      return message.replyError({
        title: "REDEEM",
        description: "This server is already premium!",
      });
    const premium = await Premium.findOne({
      code: code,
    });

    if (premium) {
      const expires = moment(Number(premium.expiresAt)).format(
        "dddd, MMMM Do YYYY HH:mm:ss"
      );

      guildDB.isPremium = "true";
      guildDB.premium.redeemedBy.id = message.author.id;
      guildDB.premium.redeemedBy.tag = message.author.tag;
      guildDB.premium.redeemedAt = Date.now();
      guildDB.premium.expiresAt = premium.expiresAt;
      guildDB.premium.plan = premium.plan;

      await guildDB.save().catch(() => {});

      await premium.deleteOne().catch(() => {});

      let ID = uniqid(undefined, `-${code}`);
      const date = require("date-and-time");
      const now = new Date();
      let DDate = date.format(now, "YYYY/MM/DD HH:mm:ss");

      try {
        await message.author.send({
          embeds: [
            new Discord.MessageEmbed()
              .setDescription(
                `**Premium Subscription**\n\nYou've recently redeemed a code in **${message.guild.name}** and here is your receipt:\n\n **Reciept ID:** ${ID}\n**Redeem Date:** ${DDate}\n**Guild Name:** ${message.guild.name}\n**Guild ID:** ${message.guild.id}`
              )
              .setColor(message.guild.me.displayHexColor)
              .setFooter({ text: message.guild.name }),
          ],
        });
      } catch (err) {
        console.log(err);
        message.channel.send({
          embeds: [
            new Discord.MessageEmbed()
              .setDescription(
                `**Congratulations!**\n\n**${message.guild.name}** Is now a premium guild! Thanks a ton!\n\nIf you have any questions please contact me [here](https://discord.gg/SPcmvDMRrP)\n\n**Could not send your Reciept via dms so here it is:**\n**Reciept ID:** ${ID}\n**Redeem Date:** ${DDate}\n**Guild Name:** ${message.guild.name}\n**Guild ID:** ${message.guild.id}\n\n**Please make sure to keep this information safe, you might need it if you ever wanna refund / transfer servers.**\n\n**Expires At:** ${expires}`
              )
              .setColor(message.guild.me.displayHexColor)
              .setFooter({ text: message.guild.name }),
          ],
        });

        return;
      }

      message.channel.send({
        embeds: [
          new Discord.MessageEmbed()
            .setDescription(
              `**Congratulations!**\n\n**${message.guild.name}** Is now a premium guild! Thanks a ton!\n\nIf you have any questions please contact me [here](https://discord.gg/SPcmvDMRrP)\n**your receipt has been sent via dms**\n\n**Expires At:** ${expires}`
            )
            .setColor(message.guild.me.displayHexColor)
            .setFooter({ text: message.guild.name }),
        ],
      });

      const embedPremium = new Discord.MessageEmbed()
        .setDescription(
          `**Premium Subscription**\n\n**${message.author.tag}** Redeemed a code in **${message.guild.name}**\n\n **Reciept ID:** ${ID}\n**Redeem Date:** ${DDate}\n**Guild Name:** ${message.guild.name}\n**Guild ID:** ${message.guild.id}\n**Redeemer Tag:** ${message.author.tag}\n**Redeemer ID:** ${message.author.id}\n\n**Expires At:** ${expires}`
        )
        .setColor(message.guild.me.displayHexColor);

      webhookClient.send({
        username: "Aeona Premium",
        avatarURL: `${process.env.domain}/logo.png`,
        embeds: [embedPremium],
      });

      return;
    } else {
      message.replyError({
        title: "REDEEM",
        description: "This code is invalid!",
      });
    }
  },
};
